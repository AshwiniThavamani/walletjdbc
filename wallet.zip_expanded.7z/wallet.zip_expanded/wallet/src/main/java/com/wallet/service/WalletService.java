package com.wallet.service;

import com.wallet.bean.Customer;
import com.wallet.dao.IWalletDao;
import com.wallet.dao.WalletDao;
import com.wallet.exception.WalletException;



public class WalletService implements IWalletService {
    IWalletDao walletdao=new WalletDao();
	public boolean validateCustomer(Customer customer) throws WalletException {
		// TODO Auto-generated method stub
			if(validateName(customer.getName())&& validateMobile(customer.getMobile())&& validateEmail(customer.getEmail())&& validateAge(customer.getAge())) {
				return true;
			}
			return false;
		}

	public boolean validateMobile(String mobile) throws WalletException {
		// TODO Auto-generated method stub
		if(mobile.isEmpty()||mobile==null) {
			throw new WalletException("Mobile should not be Empty");
		}
		else {
			if(!mobile.matches("\\d{10}")) {
				throw new WalletException("mobile number should be 10 digits");
			}
		}
		return true;
	}

	public boolean validateAge(String age) throws WalletException {
	// TODO Auto-generated method stub
		if(age.isEmpty()|| age==null) {
			throw new WalletException("Customer Age cannot be empty");	
			}
			else {
				if(!age.matches("[0-9]{2}")) {
					throw new WalletException("Age Should be 2 digits");
				}
			}
	return true;
	}	
	

		private boolean validateName(String name) throws WalletException {
			
			if(name.isEmpty()|| name==null) {
			throw new WalletException("Customer Name cannot be empty");	
			}
			else {
				if(!name.matches("[A-Z][A-Za-z]{2,}")) {
					throw new WalletException("Name Should Start with Capital letter followed by a Minimum characters");
				}
			}
			return true;
		}
		
		 private boolean validateEmail(String email )throws WalletException{
		    	if(!email.matches("[A-Za-z0-9_]+@[a-z]+\\.com")) {
		    		throw new WalletException("please enter valid email");
		    	}
		    	return true;
		    }

		public long addCustomer(Customer customer) throws WalletException {
			// TODO Auto-generated method stub
			
				return walletdao.addCustomer(customer);
			
			
		}

		@Override
		public boolean checkAccountNo(long accountNo) throws WalletException {
			// TODO Auto-generated method stub
			return walletdao.checkAccountNo(accountNo);
		}

		@Override
		public double ShowBalance(long accountNo) throws WalletException {
			// TODO Auto-generated method stub
			return walletdao.ShowBalance(accountNo);
		}

		@Override
		public double desposit(double bal,long getAccountNo) throws WalletException {
			// TODO Auto-generated method stub
			return walletdao.deposit(bal,getAccountNo);
		}

		@Override
		public double withdraw(double bal, long accountNo) throws WalletException {
			// TODO Auto-generated method stub
			return walletdao.withdraw(bal,accountNo);
		}
		

}
