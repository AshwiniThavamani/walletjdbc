package com.wallet.dao;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Optional;

import com.wallet.bean.Customer;
import com.wallet.db.WalletDB;
import com.wallet.exception.WalletException;





public class WalletDao implements IWalletDao{
	
    
	 static HashMap<Long, Customer> customerMap=WalletDB.getCustomerMap();
	

	public long addCustomer( Customer customer) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Optional<Long>id=customerMap.keySet().stream().max(new Comparator<Long>() {
				@Override
				public int compare(Long x, Long y) {
					return x>y?1:x<y?-1:0;
				}
			});
				long reqId=id.get()+1;
				customer.setAccountNo(reqId);
			
			customerMap.put(customer.getAccountNo(), customer);
			return customer.getAccountNo();
		}
		catch(Exception ex) {
			throw new WalletException(ex.getMessage());
		}
		
		
	}


	@Override
	public boolean checkAccountNo(long accountNo) throws WalletException {
		// TODO Auto-generated method stub
		
		try {
			Customer customer=customerMap.get(accountNo);
			if(customer==null) {
				throw new WalletException("Customer with account no  "+accountNo+"  not available in the database");
			}
			return true;
			}
	     	catch(Exception ex)
			
			{
			throw new WalletException(ex.getMessage());
			}
	}


	@Override
	public double ShowBalance(long accountNo) throws WalletException {
		// TODO Auto-generated method stub
		try {
		Customer customer=customerMap.get(accountNo);
		return customer.getBalance();}
     	catch(Exception ex)
		
		{
		throw new WalletException(ex.getMessage());
		}

		
	}


	@Override
	public double deposit(double bal,long getAccountNo) throws WalletException {
		// TODO Auto-generated method stub
		Customer customer=customerMap.get(getAccountNo);
		double balance=customer.getBalance();
		customer.setBalance(bal+balance);
		return customer.getBalance();
	}


	@Override
	public double withdraw(double bal, long accountNo) throws WalletException {
		// TODO Auto-generated method stub
		Customer customer=customerMap.get(accountNo);
		double balance=customer.getBalance();
		customer.setBalance(balance-bal);
		return customer.getBalance();
	}

}
