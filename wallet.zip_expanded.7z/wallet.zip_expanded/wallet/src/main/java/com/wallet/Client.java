package com.wallet;

import java.util.Scanner;

import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;
import com.wallet.service.IWalletService;
import com.wallet.service.WalletService;


public class Client 
{
	IWalletService walletService=new WalletService();
	Customer customer=new Customer();
    Scanner scan=new Scanner(System.in);
    public static void main( String[] args )
    {
    	Client c=new Client();
    	String option=null;
    	c.scan.useDelimiter("\n");
    	while(true) {
    		System.out.println("Banking Application");
    		System.out.println("1.Create Account");
    		System.out.println("2.Show Balance");
    		System.out.println("3.Deposit");
    		System.out.println("4.Withdraw");
    		System.out.println("5.Fund Transfer");
    		System.out.println("6.Print Transaction");
    		System.out.println("7.Exit");
    		System.out.println("Enter your choice:");
    		option=c.scan.nextLine();
    		switch(option) {
    		case "1":
    			c.CreateAccount();
    			break;
    		case "2":
    			c.ShowBalance();
    			break;
    		case "3":
    			c.Deposit();
    			break;
    		case "4":
    			c.Withdraw();
    			break;
    		case "5":
    			c.FundTransfer();
    			break;
    		case "6":
    			c.PrintTransaction();
    			break;
    		case "7":
    			System.exit(0);
    			break;
    		default:
    			System.err.println("Invalid Choice");
    			break;
    		
    		}
    	}
    }
    
    public void CreateAccount() {
    	
    
    	System.out.println("Enter your Account Name:");
    	customer.setName(scan.nextLine());
    	System.out.println("Enter your Gender:");
    	customer.setGender(scan.nextLine());
    	System.out.println("Enter your Age:");
    	customer.setAge(scan.nextLine());
    	System.out.println("Enter your Email Id:");
    	customer.setEmail(scan.nextLine());
    	System.out.println("Enter your Mobile Number:");
    	customer.setMobile(scan.nextLine());
    	try {
			boolean result=walletService.validateCustomer(customer);
			
			System.out.println("Customer details are validated\n");
			
			if(result) {
				long ret=walletService.addCustomer(customer);
			
				System.out.println("Customer with account number was  "+customer.getAccountNo()+"  created successfully");}
			
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			System.out.println();
			System.err.println("An Error occured   "+e.getMessage());
			System.out.println();
		}
    	
    }
    
    public void ShowBalance() {
    System.out.println("Enter your Account Number:");
   // customer.setAccountNo(scan.nextLong());
    String account=scan.nextLine();
    try {
    	long acc=Integer.parseInt(account);
    	boolean result=walletService.checkAccountNo(acc);
    	System.out.println("valid customer");
    	if(result) {
    		double d=walletService.ShowBalance(acc);
    		System.out.println("Your Balance is:"+d);
    	}
    } catch (WalletException e) {
		// TODO Auto-generated catch block
		System.out.println();
		System.err.println("An Error occured   "+e.getMessage());
		System.out.println();
	}
    
    }
    
    public void Deposit() {
    	System.out.println("Enter your Account Number:");
    	 String account=scan.nextLine();
        try {
        	long acc=Integer.parseInt(account);
        	boolean result=walletService.checkAccountNo(acc);
        	System.out.println("valid customer");
        	if(result) {
        		System.out.println("Enter amount to deposit in your account:");
        		String bal=scan.nextLine();
        		double ban2=Double.parseDouble(bal);
        		double newBalance=walletService.desposit(ban2,acc);
        		System.out.println("New Updated Balance:"+newBalance);
        	}
     }
        catch (WalletException e) {
    		// TODO Auto-generated catch block
    		System.out.println();
    		System.err.println("An Error occured   "+e.getMessage());
    		System.out.println();
    	}
        
    }
    
    public void Withdraw() {
    	System.out.println("Enter your Account Number:");
    	 String account=scan.nextLine();
        try {
        	long acc=Integer.parseInt(account);
        	boolean result=walletService.checkAccountNo(acc);
        	System.out.println("valid customer");
        	if(result) {
        		System.out.println("Enter amount to withdraw in your account:");
        		String bal=scan.nextLine();
        		double ban2=Double.parseDouble(bal);
        		double newBalance=walletService.withdraw(ban2,acc);
        		System.out.println("New Updated Balance:"+newBalance);
        	}
    }
        catch (WalletException e) {
    		// TODO Auto-generated catch block
    		System.out.println();
    		System.err.println("An Error occured   "+e.getMessage());
    		System.out.println();
    	}
        
    }
    
    public void FundTransfer() {
    	System.out.println("Enter source Account Number:");
   	    String account=scan.nextLine();
     	System.out.println("Enter destination Account Number :");
        String account1=scan.nextLine();
       try {
       	long acc=Integer.parseInt(account);
       	boolean result=walletService.checkAccountNo(acc);
       	long acc1=Integer.parseInt(account1);
       	boolean result1=walletService.checkAccountNo(acc1);
       	if(result1 && result) {
       		System.out.println("Enter the amount to tranfer");
       		String amt=scan.nextLine();
       		double ban2=Double.parseDouble(amt);
       		double newBalance=walletService.withdraw(ban2,acc);
       		double newBalance1=walletService.desposit(ban2,acc1);
       		System.out.println("New updated balance in Source account is "+newBalance);
       		System.out.println("New updated balance in Destination account is "+newBalance1);
       		
       	}	
       	}
       catch (WalletException e) {
   		// TODO Auto-generated catch block
   		System.out.println();
   		System.err.println("An Error occured   "+e.getMessage());
   		System.out.println();
   	}
    	
    	
    }
    
    public void PrintTransaction() {
    	System.out.println("Last Transaction:");
    	Client c=new Client();
    	c.ShowBalance();
    }
}
