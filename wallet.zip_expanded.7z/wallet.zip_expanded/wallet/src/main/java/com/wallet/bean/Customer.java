package com.wallet.bean;


public class Customer {
	private String name;
	private String gender;
	private String age;
	private String email;
	private String mobile;
	private double balance;
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	private long accountNo;
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public Customer() {
		
	}
	public Customer(String name, String gender, String age, String email, String mobile,long accountNo,double balance) {
		super();
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.email = email;
		this.mobile = mobile;
		this.accountNo=accountNo;
	    this.balance=balance;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", gender=" + gender + ", age=" + age + ", email=" + email + ", mobile="
				+ mobile + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

}
